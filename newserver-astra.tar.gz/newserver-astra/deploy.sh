#!/bin/bash

# generate ssh-keys
# git clone https://ci.istc-miet.ru/publicgroup/ssh.git

#LINE_NUM=$(grep -n "ssh_public_keys" vars/main.yml | cut -d: -f1)
#REPLACEMENT_LINE=$(wget --trust-server-names https://ci.istc-miet.ru/publicgroup/ssh/-/raw/main/authorized_keys?ref_type=heads -O -|grep -o 'ssh.*'|xargs -L 1)
#sed -i "${LINE_NUM}c\\${REPLACEMENT_LINE}" vars/main.yml

#ansible all -m ping
ansible-playbook new_server.yml
