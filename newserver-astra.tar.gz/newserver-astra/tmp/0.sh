#!/bin/bash

1. /etc/apt/sources.list
deb https://download.astralinux.ru/astra/stable/1.8_x86-64/repository-extended/ 1.8_x86-64 main contrib non-free non-free-firmware
deb https://download.astralinux.ru/astra/stable/1.8_x86-64/repository-devel/ 1.8_x86-64 main contrib non-free non-free-firmware
deb https://download.astralinux.ru/astra/stable/1.8_x86-64/repository-main/ 1.8_x86-64 main contrib non-free non-free-firmware
# deb cdrom:[OS Astra Linux 1.8.1.6  DVD]/ 1.8_x86-64 contrib main non-free non-free-firmware

2. apt update
3. apt dist-update -y
4. apt install qemu-guest-agent -y
5. systemctl enable qemu-guest-agent && systemctl start qemu-guest-agent
11. apt install git -y
11. apt install htop -y
6. sudo astra-modeswitch set 0

apt purge --remove -y exim4 wpasupplicant modemmanager
apt autoremove -y

8. sudo apt install fly-dm-rdp -y
9. sed /etc/X11/fly-dm/fly-dmrc
#DefaultSession=fly
DefaultSession=fly-rdp-local
10. sudo rm /home/*/.dmrc

7. /etc/default/grub
GRUB_CMDLINE_LINUX_DEFAULT="quiet splash parsec.max_ilev=0 parsec.mac=0"




12. support -add key
git clone https://ci.istc-miet.ru/publicgroup/ssh.git
13. support - remove password


