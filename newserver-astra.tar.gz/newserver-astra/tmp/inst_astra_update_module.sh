#!/bin/bash

MODULE_PATH=`ansible-config dump |grep DEFAULT_MODULE_PATH`
#
# first, copy files to directory:
# ~/.ansible/plugins/modules/astra_update/library
# astra_update.py
# __init__.py

ansible -m astra_update
