{% raw %}# ~/.bash_aliases: execute then shell run.
#
if [ -x /usr/bin/dircolors ]; then
    test -r ~/.dircolors && eval "$(dircolors -b ~/.dircolors)" || eval "$(dircolors -b)"
    alias ls='ls --color=auto --file-type -h --group-directories-first'
    alias dir='dir --color=auto'
    alias vdir='vdir --color=auto'
    alias grep='grep --color=auto'
    alias fgrep='fgrep --color=auto'
    alias egrep='egrep --color=auto'
fi

alias ll='ls -alF'
alias la='ls -A'
alias l='ls -CF'
alias alert='notify-send --urgency=low -i "$([ $? = 0 ] && echo terminal || echo error)" "$(history|tail -n1|sed -e '\''s/^\s*[0-9]\+\s*//;s/[;&|]\s*alert$//'\'')"'
# alias rdesktop='rdesktop -k en-us -a 16 -g 1024x768'
alias rdesktop='rdesktop -k en-us -a 16 -x 0x80 -z -N -g 1152x864'
alias get_site='wget -r -l 2 -k -E -p -nc'
alias install='sudo apt-get install'
alias update='sudo apt-get update'
alias remove='sudo apt-get remove'
alias search='sudo apt-cache search'
alias pyftp='python -m SimpleHTTPServer 8080'
{% endraw %}
