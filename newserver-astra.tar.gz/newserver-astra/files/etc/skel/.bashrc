{% raw %}#!/bin/bash
#
case $- in
    *i*) ;;
      *) return;;
esac
# Test for an interactive shell.
[ -z "$PS1" ] && return

# Colors -----------------------------------------------------------------------
LIGHTGRAY='\e[0;37m'
DARKGRAY='\e[1;30m'
LIGHTBLUE='\e[1;34m'
LIGHTGREEN='\e[1;32m'
LIGHTCYAN='\e[1;36m'
LIGHTRED='\e[1;31m'
LIGHTPURPLE='\e[1;35m'
BLACK=$(tput setaf 0)
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
YELLOW=$(tput setaf 3)
BLUE=$(tput setaf 4)
PURPLE=$(tput setaf 5)
CYAN=$(tput setaf 6)
WHITE=$(tput setaf 7)
DEFAULT=$(tput setaf 9)
RESET=$(tput sgr0)
END=$(tput hpa $(tput cols))$(tput cub 16)
NC='\e[0m'

# bash history tweaks ----------------------------------------------------------
HISTFILE="$HOME/.bash_history"              # hostname appended to bash history filename
HISTSIZE=40000                              # bash history will save N commands
HISTFILESIZE=${HISTSIZE}                    # bash will remember N commands
HISTCONTROL=ignoreboth                      # ingore duplicates and spaces (ignoreboth, ignoredups, ignorespace)
HISTTIMEFORMAT='%F %T '

# don't append the following to history: consecutive duplicate
# commands, ls, bg and fg, and exit
HISTIGNORE='\&:[bf]g:pwd:cd *:jobs:set -x:c:??'
HISTIGNORE=${HISTIGNORE}':%1:%2:shutdown *:checksum *:clear'
HISTCONTROL=ignoredups:ignorespace
shopt -s histappend
shopt -s checkwinsize

# make less more friendly for non-text input files, see lesspipe(1)
[ -x /usr/bin/lesspipe ] && eval "$(SHELL=/bin/sh lesspipe)"

# when connecting to SSH, start or reattach screen session ---------------------
# if [ -n "$SSH_CONNECTION" ] && [ -z "$SCREEN_EXIST" ]; then
#   export SCREEN_EXIST=1
#   screen -DR
# fi

# source some bash files -------------------------------------------------------
if [ -f $HOME/.bash_exports ]; then
    source $HOME/.bash_exports
fi
if [ -f $HOME/.bash_functions ]; then
    source $HOME/.bash_functions
fi
if [ -f $HOME/.bash_aliases ]; then
    source $HOME/.bash_aliases
fi

# set variable identifying the chroot you work in (used in the prompt below)
if [ -z "${debian_chroot:-}" ] && [ -r /etc/debian_chroot ]; then
    debian_chroot=$(cat /etc/debian_chroot)
fi

# Print Welcome Note ----------------------------------------------------------
if [ "${TERM}" != "screen-256color" -a ${EUID} != 0 ]; then
    welcomeNotes;
fi

# Change the window title of X terminals ---------------------------------------
case "$TERM" in
    xterm-color|*-256color) color_prompt=yes;;
esac
case ${TERM} in
    xterm*|*rxvt*|Eterm|aterm|kterm|gnome*|interix)
        PROMPT_COMMAND='echo -ne "\033]0;${PWD/$HOME/~}\007"'
    ;;
    screen)
        PROMPT_COMMAND='echo -ne "\033_${PWD/$HOME/~}\033\\"'
    ;;
esac
if [ -n "$force_color_prompt" ]; then
    if [ -x /usr/bin/tput ] && tput setaf 1 >&/dev/null; then
	color_prompt=yes
    else
	color_prompt=
    fi
fi

if [ "$color_prompt" = yes ]; then
  ROLE=`cat /etc/roles`
  # ROLE=`cat /etc/hostname`
  COL=`tput cols`
  printf -v line '%*s' $(( (`tput cols` - ${#ROLE} - 2) / 2 ))
  export PROMPT_COMMAND='if [[ "$?" -eq "0" ]]; then echo "${GREEN}${line// /=} ${YELLOW}${ROLE} ${GREEN}${line// /=}${CYAN}${END}Exit code:$?${RESET}"; else echo "${RED}${line// /=} ${YELLOW}${ROLE} ${RED}${line// /=}${BLUE}${END}Exit code:$?${RESET}"; fi;'
  export LS_OPTIONS='--color=auto'
  if [[ ${EUID} == 0 ]] ; then
      PS1='\[\033[01;33m\]\t \[\033[01;31m\]\u\[\033[01;34m\] \W \[\033[00m\]\# \[\033[01;31m\]\$ \[\033[00m\]'
  else
      PS1="\[\033[01;31m\]\t \[\033[01;32m\]\u\[\033[01;31m\]@\[\033[01;34m\]\h-> \W \#\[\033[01;32m\] \`if [ \$? = 0 ]; then echo \[\e[32m\]:\) \$: \[\033[00m\]; else echo \[\e[31m\]:\( \$: \[\033[00m\]; fi\`"
  fi
  export LS_OPTIONS='--color=auto'
else
    PS1='${debian_chroot:+($debian_chroot)}\u@\h:\w\$ '
fi
unset color_prompt force_color_prompt

case "$TERM" in
xterm*|rxvt*)
    PS1="\[\e]0;${debian_chroot:+($debian_chroot)}\u@\h: \w\a\]$PS1"
    ;;
*)
    ;;
esac

# advanced bash-completion
if ! shopt -oq posix; then
  if [ -f /usr/share/bash-completion/bash_completion ]; then
    . /usr/share/bash-completion/bash_completion
  elif [ -f /etc/bash_completion ]; then
    . /etc/bash_completion
  fi
fi
{% endraw %}
