# ⚡ ansible-newserver-astra

<p><b>For create or update servers Astra OS</b></p>

<br><br>

## ⚡ Installing

1. Clone the repository with:
```
git clone https://git.cifro.net/mntc/ansible-newserver-astra.git
```
2. Install the libraries with:
```
env python3 -m pip install -r requirements.txt --break-system-packages
```
<br>

## ⚡ Pre-requisites

For Atra Linux 1.8 use this libraries in requirements.txt
```
ansible==9.8.0
ansible-core=2.16.14
jinja2==3.1.2
boto3==1.34.158
dopy==0.3.7
```
<br>

## ⚡ Settings

Set actual ip-addresses all servers in inventory-file
```
[server]
server.mntc.local ansible_host=192.168.80.1

[workstation]
workstation.mntc.local ansible_host=192.168.80.2

[new_servers:children]
server
workstation
```

And actual values in variables file
```
vars/main.yml
```

### ⚡ For SINGLE standalone installation

if you plan to run the installation on a single server that is not part of the virtualization system, please replace the following values in the variable file:

```
short_hostname: true
update_system: true
qemu_fix: false
delete_old_accounts: false
node_exporter_install: false
# and replace
ntp_servers
  - "ntp.msk-ix.ru"
```
<br>

## ⚡ Getting started

<p><b> Start deploy </b></p>

1. Verify all hosts:

```
ansible all -m ping --ask-pass -vvvv

```
2. Start ansible-playbook
```
export ANSIBLE_CACHE_PLUGIN="jsonfile"
export ANSIBLE_CACHE_PLUGIN_CONNECTION="~/.ansible/fact_cache"
export ANSIBLE_CACHE_PLUGIN_TIMEOUT=7200

ansible-playbook new_server.yml --ask-pass --ask-become-pass -vvvv
```

<br><br>

[![Build Status](https://drone.cifro.net/api/badges/mntc/ansible-newserver-astra/status.svg)](https://drone.cifro.net/mntc/ansible-newserver-astra)

