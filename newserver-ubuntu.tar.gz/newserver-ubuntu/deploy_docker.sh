#!/bin/bash
# first of all, get ansible docker images
# docker pull alpine/ansible
#
# set alias in ~/.bashrc
# alias ansible="docker run -ti --rm -v ~/.ssh:/root/.ssh -v ~/.aws:/root/.aws -v $(pwd):/apps -w /apps alpine/ansible ansible"
# and run ansible playbook
# ansible <follow command>

SECONDS=0
convertsecs() {
 h=$(bc <<< "${1}/3600")
 m=$(bc <<< "(${1}%3600)/60")
 s=$(bc <<< "${1}%60")
 printf "%02d:%02d:%05.2f\n" $h $m $s
}

# sart the deployment using SSH keys:
# docker run -it --rm -v ~/.ssh:/root/.ssh -v $(pwd):/apps -w /apps alpine/ansible ansible all -m ping --ask-pass -vvvv
# docker run -it --rm -v ~/.ssh:/root/.ssh -v $(pwd):/apps -w /apps alpine/ansible ansible-playbook new_server.yml --ask-pass --ask-become-pass -vvvv

# or whithout SSH keys:
docker run -it --rm -v $(pwd):/apps -w /apps alpine/ansible ansible all -m ping --ask-pass -vvvv
docker run -it --rm -v $(pwd):/apps -w /apps alpine/ansible ansible-playbook new_server.yml --ask-pass --ask-become-pass

# or run task only:
# docker run -it --rm -v $(pwd):/apps -w /apps alpine/ansible ansible-playbook new_server.yml --ask-pass --ask-become-pass -t web-letsencrypt

convertsecs $SECONDS
