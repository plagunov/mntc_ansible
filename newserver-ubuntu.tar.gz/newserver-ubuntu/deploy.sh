#!/bin/bash
# This playbook requires root privileges or sudo.
export ANSIBLE_CACHE_PLUGIN="jsonfile"
export ANSIBLE_CACHE_PLUGIN_CONNECTION="~/.ansible/fact_cache"
export ANSIBLE_CACHE_PLUGIN_TIMEOUT=7200
SECONDS=0
convertsecs() {
 h=$(bc <<< "${1}/3600")
 m=$(bc <<< "(${1}%3600)/60")
 s=$(bc <<< "${1}%60")
 printf "%02d:%02d:%05.2f\n" $h $m $s
}

# ansible all -m ping
ansible all -m ping --ask-pass -vvvv
ansible-playbook new_server.yml --ask-pass --ask-become-pass -vvvv

convertsecs $SECONDS
