welcomeNotes() {
  HST=`hostname -f`
  echo "$HST"
}

# install and upgrade system
sagiall() {
sudo apt-get update && sudo apt-get upgrade -y && sudo apt-get dist-upgrade -y
}

# Auto Get Missing Launchpad Keys
sagikey() {
sudo apt-get update 2> /tmp/keymissing; for key in $(grep "NO_PUBKEY" /tmp/keymissing |sed "s/.*NO_PUBKEY //"); do echo -e "\nProcessing key: $key"; gpg --keyserver pool.sks-keyservers.net --recv $key && gpg --export --armor $key |sudo apt-key add -; done
}

rate()
{
while [ /bin/true ]; do OLD=$NEW; NEW=`cat /proc/net/dev | grep eth0 | tr -s ' ' | cut -d' ' -f "3 11"`; echo $NEW $OLD | awk '{printf("\rin: % 9.2g\t\tout: % 9.2g", ($1-$3)/1024, ($2-$4)/1024)}'; sleep 1; done
}

localIP()
{
ifconfig ${1:--a} | sed '/Link encap\|inet\|6 addr/!d;s/Link encap.*$//;s/.*inet addr:\([0-9\.]*\).*/\1/g;s/.*inet6 addr: \(.*\) .*/\1/g' ;
}

lsmac()
{
ifconfig -a | sed '/eth\|wl/!d;s/ Link.*HWaddr//' ;
}

lsport() {
sudo netstat -tlnp
}

# Remove all unused kernels with apt-get
old_kernel() {
sudo apt-get purge $(dpkg -l 'linux-*' | sed '/^ii/!d;/'"$(uname -r | sed "s/\(.*\)-\([^0-9]\+\)/\1/")"'/d;s/^[^ ]* [^ ]* \([^ ]*\).*/\1/;/[0-9]/!d' | head -n -1) --assume-yes
}

# Find files older than 60 days
oldfiles() {
find . -maxdepth 1 -type f -mtime +60 -exec ls -l {} \;
}

# convert uppercase filenames in current directory to lowercase
up2low() {
for x in *;do mv "$x" "`echo $x|tr [A-Z] [a-z]`";done
}

# Find the package a command belongs to on debian-based distros
whichpkg() {
dpkg -S $1 | egrep -w $(readlink -f "$(which $1)")$; 
}

# find duplicate processes
dproc() {
ps aux | sort --key=11 | uniq -c -d --skip-fields=10 | sort -nr --key=1,1
}

# All IP connected to my host
lsconnect() {
netstat -lantp | grep ESTABLISHED |awk '{print $5}' | awk -F: '{print $1}' | sort -u
}

# Gets the english pronunciation of a phrase
#  say hello
# For multiword
#  say how+are+you
# say() {
# wget -q -U Mozilla -O output.mp3 "http://translate.google.com/translate_tts?tl=en&q=$1"; gnome-terminal -x bash -c "totem output.mp3"; sleep 4; totem --quit;
# }

# Gets the english pronunciation of a phrase 
# Usage: say hello world how are you today
say() {
local IFS=+;mplayer "http://translate.google.com/translate_tts?q=$*"; 
}

# Text message on wallpaper
# wallpaperWarn() {
# BG="/desktop/gnome/background/picture_filename"; convert "`gconftool-2 -g $BG`" -pointsize 70 -draw "gravity center fill red text 0,-360 'Warn' fill white text 0,360 'Warn'" /tmp/w.jpg; gconftool-2 --set $BG -t string "/tmp/w.jpg"; 
# }

# Server load and process monitoring
sload(){
watch -n1 "uptime && ps auxw|grep http|grep -v grep | grep -v watch|wc -l && netstat -ntup|grep :80 |grep ESTABLISHED|wc -l && netstat -ntup|grep :80|grep WAIT|wc -l && free -mo && ps -ylC httpd --sort:rss|tail -3|awk '{print \$8}'"
}

# tree files
lstree(){
# tree -ifs --noreport .|sort -n -k2
tree -ifsF --noreport .|sort -n -k2|grep -v '/$' 
}

# Log Out
logoff(){
gnome-session-quit --logout --no-prompt ; }
