# ⚡ ansible-newserver-ubuntu

<p><b>For create and update servers Ubuntu (Debian) OS</b></p>

<br><br>

## ⚡ Installing

1. Clone the repository with:
```
git clone https://git.cifro.net/mntc/ansible-newserver-ubuntu.git
```
2. Install the libraries with:
```
env python3 -m pip install -r requirements.txt --break-system-packages
```
<br>

## ⚡ Pre-requisites

For Ubuntu 24.04 use this libraries in requirements.txt
```
ansible==9.8.0
ansible-core=2.16.14
jinja2==3.1.2
boto3==1.34.158
dopy==0.3.7
```
<br>

## ⚡ Settings

Set actual ip-addresses all servers in inventory-file
```
[kubeadm]
kubeadm.mntc.local ansible_host=10.1.0.2

[k8s]

[fwa]
fwa.mntc.local ansible_host=10.1.0.1

[workstation]
template.mntc.local ansible_host=10.1.0.3

[new_servers:children]
kubeadm
k8s
fwa
template
```

And actual values in variables file
```
vars/main.yml
```
<br>

## ⚡ Getting started

<p><b> Start deploy </b></p>

1. Verify all hosts:

```
ansible all -m ping --ask-pass -vvvv

```
2. Start ansible-playbook
```
export ANSIBLE_CACHE_PLUGIN="jsonfile"
export ANSIBLE_CACHE_PLUGIN_CONNECTION="~/.ansible/fact_cache"
export ANSIBLE_CACHE_PLUGIN_TIMEOUT=7200

ansible-playbook new_server.yml --ask-pass --ask-become-pass -vvvv
```

<br><br>

[![Build Status](https://drone.cifro.net/api/badges/mntc/ansible-newserver-ubuntu/status.svg)](https://drone.cifro.net/mntc/ansible-newserver-ubuntu)
